The editor must be run from the pc directory.

You can run it from the command prompt or by starting the editor.bat file.