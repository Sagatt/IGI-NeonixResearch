import os 
import numpy as np
from .import struct_iff
from .import reader_ilff
from .struct_iff import *
from .reader_ilff import *

def fromtree(ifffilename):

    ifftext = "" 
    
    reader = reader_ilff.open(srcpth)
    
    print ("\n Animation File IFF -- " + str(os.path.basename(ifffilename)))

    if reader.find(b'DHNA'):
            
# Initial text (Newobject)

        ifftext += "\n\\\ Anim Name \n\n"
        ifftext += "[(\"" + str(os.path.basename(ifffilename)) + "\")]\n"
        ifftext += "\n\n"

        dhna_bytes = reader.read(b'DHNA')  
        dhna = parse_dhna(dhna_bytes) 
        
# DHNA

        ifftext += "\n\\\ Anim Info \n\n"
        ifftext += str(dhna)
        ifftext += "\n\n"
        
        reih_bytes = reader.read(b'REIH')
        reih = parse_reih(reih_bytes)        
        
# REIH

        ifftext += "\n\n\\\ Bone Links \n\n"
        ifftext += str(reih[0])
        ifftext += "\n\n\\\ Bone Hierarchy \n\n"                      
        ifftext += str(reih[1])
        ifftext += "\n\n"

        tnve_bytes = reader.read(b'TNVE')
        tnve = parse_tnve(tnve_bytes)        
        
# TNVE

        ifftext += "\n\n\\\ Translational KeyFrames \n\n"
        ifftext += str(tnve[0])

        ifftext += "\n\n\\\ Rotational KeyFrames \n\n"
        ifftext += str(tnve[1])

        ifftext += "\n\n\\\ TriggerData \n\n"
        ifftext += str(tnve[2])

        ifftext += "\n\n\\\ AttachObject KeyFrames \n\n"
        ifftext += str(tnve[3])

        ifftext += "\n\n\\\ Link Events \n\n"
        ifftext += str(tnve[4])

        ifftext += "\n\n\\\ Anim Data \n\n"
        ifftext += str(tnve[5])
        
        if reader.find(b'ATTA'):
            
            atta_bytes = reader.read(b'ATTA')
            atta = parse_atta(atta_bytes)

# ATTA

            ifftext += "\n\n\\\ Attachments \n\n"
            ifftext += str(atta)
            ifftext += "\n"
        
    return ifftext
