import os 
import numpy as np
from .import struct_iff
from .import reader_ilff
from .import iff_1st
from .import iff_3rd
from .reader_ilff import *
from .iff_1st import *
from .iff_3rd import *
from .struct_iff import *

def fromtree(ifffilename):

    ifftext = ""
    
    reader = reader_ilff.open(srcpth)
    
    if reader.find(b'DHNA'):
        dhna_bytes = reader.read(b'DHNA')
        dhna = parse_dhna(dhna_bytes)
    
        if dhna['num_bones'] == 47:
             print ("\n * Anim Type is 1st Person anim - " + os.path.basename(ifffilename)) 
             ifftext = iff_1st.fromfile(ifffilename,srcpth)

        elif dhna['num_bones'] == 31:
             print ("\n * Anim Type is 3rd Person anim - " + os.path.basename(ifffilename)) 
             ifftext = iff_3rd.fromfile(ifffilename,srcpth) 
        else:
             print ("\n * Anim Type is Undefined - " + os.path.basename(ifffilename)) 
             ifftext = input("Error!")      
        
    return ifftext

def fromtype(ifffilename):

    NamModel = str(os.path.splitext(os.path.basename(ifffilename))[0])
    
    ifftext = "CreateAnim(\"" + str(NamModel) + "\");\n"    
        
    return ifftext
