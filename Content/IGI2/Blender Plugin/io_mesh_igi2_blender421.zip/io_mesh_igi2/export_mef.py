
def save_mef(*args, **kwargs):
    pass


def save(*args, **kwargs):
    save_mef(*args, **kwargs)

    return {'FINISHED'}

