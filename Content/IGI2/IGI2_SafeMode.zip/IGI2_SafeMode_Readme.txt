WARNING: This safemode patch for IGI2: Covert Strike ("IGI2") is intended for advanced computer users only. 

If you are unable to play IGI2 or if you are experiencing critical graphical issues then this executable may help you. 

The executable works by changing DirectX settings in your computer's registry related to graphical performance. While we have not encountered any problems during testing, it might be possible that the changes made by using safemode setting could cause problems with other games or applications that you may be running.

Codemasters takes no responsibility and will not be liable for any loss or damage caused by installing or using the IGI2 safemode patch on your computer.