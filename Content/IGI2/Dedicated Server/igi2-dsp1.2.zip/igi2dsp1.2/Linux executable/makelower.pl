#!/usr/bin/perl
#
# Script: makelower.pl - Convert all filesnames in a directory to lower case
# Usage:  makelower.pl <full path to starting directory>
#
# Description:
#   This script converts all filenames in a directory to lower case.
#   It operates recursively, converting all filenames in all 
#   subdirectories of the starting directory. The only input parameter
#   is the full path to the starting directory. NOTE: THIS WILL ONLY
#   RUN ON UNIX FILESYSTEMS (i.e., it has not been made cross-platform).
# End:
#

use File::Find;
use File::Basename;

# Get starting directory
$usage = "Usage: makelower.pl <full path to starting directory>";
$start_dir = shift or die "$usage\n";
$start_dir =~ s/\W+$//;  # Lose trailing non-alphanumerics
die "Can\'t find $start_dir\n" unless (-e $start_dir);
die "$start_dir isn\'t a directory\n" unless (-d $start_dir);
unless ($start_dir =~ m|^\/|) {
    die "Must give the full path name for $start_dir\n";
}
 
# Announce intentions
print "Making lowercase filenames - starting with $start_dir...\n";

# Process all non-directory files recursively
finddepth(\&make_lower, $start_dir);
print "Done.\n";

rename ("pc/language/danish", "pc/language/DANISH");
rename ("pc/language/english", "pc/language/ENGLISH");
rename ("pc/language/finnish", "pc/language/FINNISH");
rename ("pc/language/french", "pc/language/FRENCH");
rename ("pc/language/german", "pc/language/GERMAN");
rename ("pc/language/italian", "pc/language/ITALIAN");
rename ("pc/language/norwegian", "pc/language/NORWEGIAN");
rename ("pc/language/spanish", "pc/language/SPANISH");
rename ("pc/language/swedish", "pc/language/SWEDISH");
rename ("pc/language/usa", "pc/language/USA");

rename ("pc/common/sounds/english", "pc/common/sounds/ENGLISH");
rename ("pc/common/sounds/french", "pc/common/sounds/FRENCH");
rename ("pc/common/sounds/german", "pc/common/sounds/GERMAN");

#######################
# Support Subroutines #
#######################

# Subroutine that does all the work
sub make_lower {

     # Make the basename of each file/directory lowercase
     $file = $File::Find::name;
     $path = dirname($file);
     $name = basename($file);
     $new_name = lc $name;
     $new_file = $path . "/" . $new_name;

     # Do the actual renaming
     rename ($file, $new_file) or die "Can't rename $file: $!\n";
}
