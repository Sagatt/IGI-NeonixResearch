Project I.G.I 1 Compiler is all in one IGI 1 Compiler/Decompiler tool which lets you compile game scripts files '.qsc' for the game.
and lets you to decompile '.qvm' files as well.

Compiler sections.
Compiler -  Lets you to compile game script 'objects.qsc' to game binary 'objects.qvm'.
DeCompiler -  Lets you to decompile game binary files 'objects.qvm' to game script 'objects.qsc'.
Editor - Compiler has built in editor uses Notepad/Notepad++ to edit scripts files.
Game Run - Compiler create shotcut for your game after compiling it will automatically run the game to see changes effect.


Compiler features.
Compiler can compile all type of game scripts and can compile/decompile multiple files at same time.
And advances built in QCompiler and QDecompiler to compile QScripts of IGI Game that can permanently store you data in ".qvm" file.
Stores path of game and output permanently.

'Script File' - Contains game script file for Level 1 -3 for demo data.